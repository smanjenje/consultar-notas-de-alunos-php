Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/dynamically-load-content-in-bootstrap-modal-with-ajax/

Instruction - 

## Import attached employee.sql file in your database
## Update config.php
