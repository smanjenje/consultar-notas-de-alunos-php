$(document).ready(function(){
$('#turma').empty();
$('#classe').empty();
comeca();

$('#saveNota').submit(function(e) {
          e.preventDefault();
          $.ajax({
            type:'post',    //Definimos o método HTTP usado
            dataType: 'json', //Definimos o tipo de retorno
            url: 'script.php?op=saveNota',
            data: $(this).serialize(),//Definindo o arquivo onde serão buscados os dados
            success: function(dados){
             if (dados.success==1) {
              alert(dados.nome);
             }else if (dados.success==0){
              alert('erro');
             }
              }
            });
        });

    $.ajax({
    type:'post',    //Definimos o método HTTP usado
    dataType: 'json', //Definimos o tipo de retorno
    url: 'script.php?op=getAluno',//Definindo o arquivo onde serão buscados os dados idturma
    success: function(dados){
      var numAluno=0;
      for(var i=0;dados.length>i;i++){
        //Adicionando registros retornados na tabela
parseInt()
        numAluno++;
        $('#pauta').append(
          '<tr>'+
          '<td>'+numAluno+'</td>'+
          '<td>'+dados[i].nome+'</td>'+
          '<td><form id="pt" class="nta"><input type="hidden" name="id" value="'+dados[i].id+'"><input type="hidden" name="p1" value="'+dados[i].p1+'" class="p1'+dados[i].id+'"><input type="submit" size="3" value="'+dados[i].p1+'" id="pp'+dados[i].id+'" class="p1'+dados[i].id+'"></form></td>'+
          '<td><form id="pt" class="nta"><input type="hidden" name="id" value="'+dados[i].id+'"><input type="hidden" name="p2" value="'+dados[i].p2+'" class="p2'+dados[i].id+'"><input type="submit" size="3" value="'+dados[i].p2+'" id="pp'+dados[i].id+'" class="p2'+dados[i].id+'"></form></td>'+
          '<td>'+eval((parseInt(dados[i].p1)+parseInt(dados[i].p2))/2)+'</td>'+

          '<td><form id="pt" class="nta"><input type="hidden" name="id" value="'+dados[i].id+'"><input type="hidden" name="p3" value="'+dados[i].p3+'" class="p3'+dados[i].id+'"><input type="submit" size="3" value="'+dados[i].p3+'" id="pp'+dados[i].id+'" class="p3'+dados[i].id+'"></form></td>'+
          '<td><form id="pt" class="nta"><input type="hidden" name="id" value="'+dados[i].id+'"><input type="hidden" name="p4" value="'+dados[i].p4+'" class="p4'+dados[i].id+'"><input type="submit" size="3" value="'+dados[i].p4+'" id="pp'+dados[i].id+'" class="p4'+dados[i].id+'btn btn-primary"></form></td>'+
          
          '<td>'+eval((parseInt(dados[i].p3)+parseInt(dados[i].p4))/2)+'</td>'+
          '<td><form id="pt" class="nta"><input type="hidden" name="id" value="'+dados[i].id+'"><input type="hidden" name="p5" value="'+dados[i].p5+'" class="p5'+dados[i].id+'"><input type="submit" size="3" value="'+dados[i].p5+'" id="pp'+dados[i].id+'" class="p5'+dados[i].id+'"></form></td>'+
          '<td><form id="pt" class="nta"><input type="hidden" name="id" value="'+dados[i].id+'"><input type="hidden" name="p6" value="'+dados[i].p6+'" class="p6'+dados[i].id+'"><input type="submit" size="3" value="'+dados[i].p6+'" id="pp'+dados[i].id+'" class="p6'+dados[i].id+'"></form></td>'+
          
          '<td>'+eval((parseInt(dados[i].p5)+parseInt(dados[i].p6))/2)+'</td>'+
      
          '<td><form id="" class="editar"><input type="hidden" name="id" value="'+dados[i].id+'"> <button type="submit" class="btn btn-xs btn-danger">Editar</button></form></td>'+
          '</tr>'
          );
   teste();
      }
        
       cadNota();
    }
  });
    
  $.ajax({
    type:'post',    //Definimos o método HTTP usado
    dataType: 'json', //Definimos o tipo de retorno
    url: 'script.php?op=getClasse',//Definindo o arquivo onde serão buscados os dados
    success: function(dados){
      for(var i=0;dados.length>i;i++){
        //Adicionando registros retornados na tabela
        $('#classe').append('<option value="'+dados[i].id_classe+'">'+dados[i].classe+'ª</option>');
        $('.classe').append('<option value="'+dados[i].id_classe+'">'+dados[i].classe+'ª</option>');
        
      }
    }
  });

  $.ajax({
    type:'post',    //Definimos o método HTTP usado
    dataType: 'json', //Definimos o tipo de retorno
    url: 'script.php?op=getDisciplina',//Definindo o arquivo onde serão buscados os dados
    success: function(dados){
      for(var i=0;dados.length>i;i++){
        //Adicionando registros retornados na tabela
        // $('#discipli').append('<option value="'+dados[i].id_disciplina+'">'+dados[i].disciplina+'ª</option>');
        $('.discipli').append('<option value="'+dados[i].id_disciplina+'">'+dados[i].disciplina+'</option>');
        
      }
    }
  });

  $.ajax({
    type:'post',    //Definimos o método HTTP usado
    dataType: 'json', //Definimos o tipo de retorno
    url: 'script.php?op=setDisciplina',//Definindo o arquivo onde serão buscados os dados
    success: function(dados){
      if (dados.success==1) {
          $('#adddisplina').modal('show');
          
         }else if (dados.success==0) {
           $('.sesDisciplina').text(dados.sesDisciplina);
         }
    }
  });

  $('#sessionDisciplina').submit(function(e) {
    e.preventDefault();

    $.ajax({
      type:'post',    //Definimos o método HTTP usado
      dataType: 'json', //Definimos o tipo de retorno
      url: 'script.php?op=sessDiscipli',
      data: $(this).serialize(),//Definindo o arquivo onde serão buscados os dados
      success: function(dados){
         if (dados.success==1) {
          $('#adddisplina').modal('hide');
          location.href = 'index.php';
         }else if (dados.success==0) {
           alert(dados.info);
         }
      }
    });

 });

   $.ajax({
    type:'post',    //Definimos o método HTTP usado
    dataType: 'json', //Definimos o tipo de retorno
    url: 'script.php?op=getTurma',//Definindo o arquivo onde serão buscados os dados idturma
    success: function(dados){
      for(var i=0;dados.length>i;i++){
        //Adicionando registros retornados na tabela
        $('#turma').append('<option value="'+dados[i].id_turma+'">'+dados[i].turma+'</option>');
        $('.turma').append('<option value="'+dados[i].id_turma+'">'+dados[i].turma+'</option>');
      }
    }
  });
     

	$('.addaluno').click(function(){
		// Display Modal
		$('#addaluno').modal('show');
		// alert('ola'); 
	});
    $('.print').click(function(){
    window.print();
  });
	$('.addturma').click(function(){
		// Display Modal
		$('#addturma').modal('show');
		// alert('ola'); 
	});
	$('.addclasse').click(function(){
		// Display Modal
		$('#addclasse').modal('show');
		// alert('ola'); 
	});




$('#cadturma').submit(function(e) {
    e.preventDefault();

    $.ajax({
      type:'post',    //Definimos o método HTTP usado
      dataType: 'json', //Definimos o tipo de retorno
      url: 'script.php?op=cadturma',
      data: $(this).serialize(),//Definindo o arquivo onde serão buscados os dados
      success: function(dados){
         if (dados.success==1) {
          $('#cadturma')[0].reset();
          alert(dados.nome);
          $('#addturma').modal('hide');
         }else if (dados.success==0) {
           alert(dados.info);
         }
      }
    });

 });

$('#cadclasse').submit(function(e) {
    e.preventDefault();

    $.ajax({
      type:'post',    //Definimos o método HTTP usado
      dataType: 'json', //Definimos o tipo de retorno
      url: 'script.php?op=cadclasse',
      data: $(this).serialize(),//Definindo o arquivo onde serão buscados os dados
      success: function(dados){
         if (dados.success==1) {
          $('#cadclasse')[0].reset();
          alert(dados.nome);
          $('#addclasse').modal('hide');
         }else if (dados.success==0) {
           alert(dados.info);
         }
      }
    });

 });

$('#cadaluno').submit(function(e) {
    e.preventDefault();

    $.ajax({
      type:'post',    //Definimos o método HTTP usado
      dataType: 'json', //Definimos o tipo de retorno
      url: 'script.php?op=cadaluno',
      data: $(this).serialize(),//Definindo o arquivo onde serão buscados os dados
      success: function(dados){
         if (dados.success==1) {
          $('#cadaluno')[0].reset();
          alert(dados.nome);
          $('#addaluno').modal('hide');
         }else if (dados.success==0) {
           alert(dados.info);
         }
      }
    });

 });

$('.letPauta').click(function(e) {
    e.preventDefault();

   $.ajax({
                url:'script.php?op=letpaut',
                type:'post',
                data:{funlet:'deixar'},
                success:function(response){
                    var msg = "";
                    if(response == 1){
                        window.location = "nodisciplina.php";
                    }else{
                        msg = "Invalid username and password!";
                    }
                    $("#message").html(msg);
                }
            });
   
});

$('#edtaluno').submit(function(e) {
    e.preventDefault();

    $.ajax({
      type:'post',    //Definimos o método HTTP usado
      dataType: 'json', //Definimos o tipo de retorno
      url: 'script.php?op=edTaluno',
      data: $(this).serialize(),//Definindo o arquivo onde serão buscados os dados
      success: function(dados){
         if (dados.success==1) {
          $('#edtaluno')[0].reset();
          alert(dados.nome);
          $('#edtaluno').modal('hide');
         }else if (dados.success==0) {
           alert(dados.info);
         }
      }
    });
    

 });

});
function teste() {
//        $('#pt').submit(function(e) {
//           e.preventDefault();
//           
// });

$('.editar').each(function() {
      $(this).submit(function(e) {
          e.preventDefault();
          $.ajax({
            type:'post',    //Definimos o método HTTP usado
            dataType: 'json', //Definimos o tipo de retorno
            url: 'script.php?op=getNt',
            data: $(this).serialize(),//Definindo o arquivo onde serão buscados os dados
            success: function(dados){
              for(var i=0;dados.length>i;i++){
                $('#edtnome').val(dados[i].nome);
                $('#edtid').val(dados[i].id);
                $('#edtaluno').modal('show');
                $('#edtaluno').modal('handleUpdate')
                // edtturma
                // edtclasse
              }
              }
            });
        });
    });
}

 var timerI = null;
      var timerR = false;

      function para(){
          if(timerR)
              clearTimeout(timerI)
          timerR = false;
      }
      function comeca(){
          para();
          lista();
      }
 function lista(){
    

        timerI = setTimeout("lista()", 1000);//tempo de espera
                  timerR = true;
                  
      }

function cadNota() {
// 
$('.nta').each(function() {
   $(this).submit(function(e) {
          e.preventDefault();
          $.ajax({
            type: "POST",//Definimos o tipo de retorno
            url: 'script.php?op=cadnota',
            data: $(this).serialize(),//Definindo o arquivo onde serão buscados os dados
            success: function(dados){
              var jsonData = JSON.parse(dados);

              if (jsonData.success == "1")
                {
                  if (jsonData.prova==1) {
                    // alert(jsonData.p);
                    $('#alunota').text(jsonData.p);
                    $('#alunoid').val(jsonData.idn);
                    $('#getnota').modal('show');
                    // alert(jsonData.prova+'|'+jsonData.idn);
                    // $('.p'+jsonData.prova+jsonData.idn).val('.p'+jsonData.prova+'|'+jsonData.idn);
                  }else if (jsonData.prova==2) {
                    $('#alunota').text(jsonData.p);
                    $('#alunoid').val(jsonData.idn);
                    $('#getnota').modal('show');
                    // alert(jsonData.p);
                    // alert(jsonData.prova+'|'+jsonData.idn);
                    // $('.p'+jsonData.prova+jsonData.idn).val('.p'+jsonData.prova+'|'+jsonData.idn);
                  }else if (jsonData.prova==3) {
                    $('#alunota').text(jsonData.p);
                    $('#alunoid').val(jsonData.idn);
                    $('#getnota').modal('show');
                    // alert(jsonData.p);
                    // alert(jsonData.prova+'|'+jsonData.idn);
                    // $('.p'+jsonData.prova+jsonData.idn).val('.p'+jsonData.prova+'|'+jsonData.idn);
                  }else if (jsonData.prova==4) {
                    $('#alunota').text(jsonData.p);
                    $('#alunoid').val(jsonData.idn);
                    $('#getnota').modal('show');
                    // alert(jsonData.p);
                    // alert(jsonData.prova+'|'+jsonData.idn);
                    // $('.p'+jsonData.prova+jsonData.idn).val('.p'+jsonData.prova+'|'+jsonData.idn);
                  }else if (jsonData.prova==5) {
                    $('#alunota').text(jsonData.p);
                    $('#alunoid').val(jsonData.idn);
                    $('#getnota').modal('show');
                    // alert(jsonData.p);
                    // alert(jsonData.prova+'|'+jsonData.idn);
                    // $('.p'+jsonData.prova+jsonData.idn).val('.p'+jsonData.prova+'|'+jsonData.idn);
                  }else if (jsonData.prova==6) {
                    $('#alunota').text(jsonData.p);
                    $('#alunoid').val(jsonData.idn);
                    $('#getnota').modal('show');
                    // alert(jsonData.p);
                    // alert(jsonData.prova+'|'+jsonData.idn);
                    // $('.p'+jsonData.prova+jsonData.idn).val('.p'+jsonData.prova+'|'+jsonData.idn);
                  }
                  if (jsonData.prova>=1 && jsonData.prova<=2) {
                    $('#trimestre').text('1º');
                    $('#prova').val(jsonData.prova);
                  }
                  else if (jsonData.prova>=3 && jsonData.prova<=4) {
                    $('#trimestre').text('2º');
                    $('#prova').val(jsonData.prova);
                  }

                  else if (jsonData.prova>=5 && jsonData.prova<=6) {
                    $('#trimestre').text('3º');
                    $('#prova').val(jsonData.prova);
                  }
                  // else if (jsonData.prova==3 && jsonData.prova<5) {
                  //   $('#trimestre').text('2º Trimestre');
                  // }else if (jsonData.prova==5 && jsonData.prova<) {
                  //   $('#trimestre').text('2º Trimestre');
                  // }
                }
              }
            });
        });
});
}

