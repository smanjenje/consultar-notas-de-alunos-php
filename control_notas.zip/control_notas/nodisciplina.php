<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>sem disciplina</title>
	  <link href='bootstrap/css/bootstrap.min.css' rel='stylesheet' type='text/css'>
	  <link href='bootstrap/css/bootstrap.theme.min.css' rel='stylesheet' type='text/css'>
  <!-- Script -->
  <meta charset="utf-8">
  <script src='bootstrap/js/jquery-3.1.1.min.js' type='text/javascript'></script>
  <script src='bootstrap/js/bootstrap.min.js' type='text/javascript'></script>
  <script src='script.js' type='text/javascript'></script>
</head>
<body>
	<a href="index.php" class="btn btn-dark ">mini pauta</a>
</body>
</html>