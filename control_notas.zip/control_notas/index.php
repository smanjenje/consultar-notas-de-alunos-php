<html>
<head>
  <title>Bootstrap Modal com AJAX| Boletim de notas</title>
  <link href='bootstrap/css/bootstrap.min.css' rel='stylesheet' type='text/css'>
  <!-- Script -->
  <meta charset="utf-8">
  <script src='bootstrap/js/jquery-3.1.1.min.js' type='text/javascript'></script>
  <script src='bootstrap/js/bootstrap.min.js' type='text/javascript'></script>
  <script src='script.js' type='text/javascript'></script>
</head>
<body>
  <div class="container theme-showcase" role="main">
    <div class="page-header">
      <h1>Listar pauta</h1>
      <div class="row">
        <div class="col-md-12">
          <b>Disciplina:</b><span class="sesDisciplina"></span>
          <button type="button" class="btn btn-xs letPauta">Deixar mini pauta</button>
        </div>
    </div>
    <hr>
<div class="row">
        <div class="col-md-12">
          <button type="button" class="btn btn-xs btn-primary addaluno">Add aluno</button>
          <button type="button" class="btn btn-xs btn-warning addturma">Add turma</button>
          <button type="button" class="btn btn-xs btn-danger addclasse">Add classe</button>
          <button type="button" class="btn btn-xs btn-danger print">print</button>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-12">
        <table class="table table-bordered table-sm">
          <thead>
            <tr>
              <th></th>
              <th></th>
              <th colspan="3" class="text-center">1ª trimestre</th>
              <th colspan="3" class="text-center">2ª trimestre</th>
              <th colspan="3" class="text-center">3ª trimestre</th>
              <th>opção</th>
            </tr>
            <tr>
              <th>Nº</th>
              <th>Nome</th>
              <th>1ª prova</th>
              <th>2ª prova</th>
              <th>media</th>
              <th>1ª prova</th>
              <th>2ª prova</th>
              <th>media</th>
              <th>1ª prova</th>
              <th>2ª prova</th>
              <th>media</th>
              <th></th>
            </tr>
          </thead>
          <tbody id="pauta"></tbody>
        </table>
      </div>
    </div>
    
  </div>
<?php require "modal.php"; ?>
</body>
</html>
