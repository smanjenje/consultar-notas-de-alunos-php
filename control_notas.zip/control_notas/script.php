<?php
session_start();
$link = new mysqli("localhost", "root", "", "test");
$hoje = date('Y/m/d');
if(isset($_GET['op']) && !empty(isset($_GET['op']))) {
    $action = $_GET['op'];
    switch($action) {
        case 'cadturma' : cadturma($link);break;
        case 'cadclasse' : cadclasse($link);break;
        case 'cadaluno' : cadaluno($link);break;
        case 'getClasse' : getClasse($link);break;
        case 'getTurma' : getTurma($link);break;
        case 'getAluno' : getAluno($link);break;
        case 'getNt' : getNt($link);break;
        case 'edTaluno' : edTaluno($link);break;
        case 'cadnota' : cadnota($link);break;
        case 'getDisciplina' : getDisciplina($link);break;
        case 'setDisciplina' : setDisciplina($link);break;
        case 'sessDiscipli' : sessDiscipli($link);break;
        case 'letpaut' : letpaut($link);break;
        case 'saveNota' : saveNota($link);break;


    }
}

function saveNota($link)
{
   if (isset($_REQUEST['edtnota'])) {
    $nota=$_REQUEST['edtnota'];
    $posi='p'.$_REQUEST['p'];
    $alunoid=$_REQUEST['alunoid'];
   
    $insert="UPDATE alunota SET $posi = $nota WHERE alunota.id = $alunoid ";
    $query=mysqli_query($link, $insert);
    if ($query>0) {
      echo json_encode(array('success' => 1,'nome'=>$alunoid));
    }
       
   }
}

function getDisciplina($link)
{
   $query = mysqli_query($link, "SELECT * FROM disciplinas ORDER BY disciplina");    
    while($resultado = mysqli_fetch_assoc($query)){
        $vetor[] = array_map('utf8_encode', $resultado); 
    }
    //Passando vetor em forma de json
    echo json_encode($vetor);
}

function letpaut($link)
{
  if (isset($_SESSION['disciplina'])) 
  {
    unset($_SESSION['disciplina']);
    // echo json_encode(array('success' => 1));
    echo 1;
  }
    
}

function setDisciplina($link)
{
  if (!isset($_SESSION['disciplina'])) 
  {
    echo json_encode(array('success' => 1));
  }else{

    echo json_encode(array('success' => 0, 'sesDisciplina'=>$_SESSION['disciplina']));
  }
    
}
function sessDiscipli($link)
{
  if (!isset($_SESSION['disciplina'])) 
  {
    $_SESSION['disciplina']=$_REQUEST['discipli'];
    echo json_encode(array('success' => 1, 'sesDisciplina'=>$_SESSION['disciplina']));

  }else{
    echo json_encode(array('success' => 0));
  }
    
}

function cadturma($link)
{
   if (isset($_REQUEST['nome'])) {
    $nome = $_REQUEST['nome'];
    $insert="INSERT INTO turma(turma) VALUES ('$nome')";
    $query=mysqli_query($link, $insert);
    if ($query>0) {
      echo json_encode(array('success' => 1,'nome'=>$nome));
    }
       
   }
}

function cadclasse($link)
{
   if (isset($_REQUEST['nome'])) {
    $nome = $_REQUEST['nome'];
    $insert="INSERT INTO classe(classe) VALUES ('$nome')";
    $query=mysqli_query($link, $insert);
    if ($query>0) {
      echo json_encode(array('success' => 1,'nome'=>$nome));
    }
       
   }
}

function cadaluno($link)
{
   if (isset($_REQUEST['nome'])) {
    $max0="SELECT * FROM ano order by id_ano desc limit 1";
     $result0=mysqli_query($link, $max0);
    while ($linha = mysqli_fetch_array($result0)){
      $id_ano=$linha['id_ano'];
    }

    $nome =utf8_decode($_REQUEST['nome']);
    $turma=$_REQUEST['turma'];
    $classe=$_REQUEST['classe'];
    
    $insert="INSERT INTO aluno( nome,id_turma,id_classe,id_ano) VALUES ('$nome','$turma','$classe','$id_ano')";
    $query=mysqli_query($link, $insert);

     $max1="SELECT * FROM aluno order by id desc limit 1";
     $result1=mysqli_query($link, $max1);
    while ($linha1 = mysqli_fetch_array($result1)){
      $maxid=$linha1['id'];
    }
    

    $insert2="INSERT INTO nota (id_aluno,id_disciplina,id_turma,id_ano,p1,p2,p3,p4,p5,p6)VALUES ($maxid, 1, 1, $id_ano, '', '', '', '', '', '')";
    $query2=mysqli_query($link, $insert2);
    

    if ($query>0) {
      echo json_encode(array('success' => 1,'nome'=>'Aluno '.$maxid.' cadastrado com sucesso'));
    }
       
   }
}



function getClasse($link)
{
    $query = mysqli_query($link, "SELECT * FROM classe");    
    while($resultado = mysqli_fetch_assoc($query)){
        $vetor[] = array_map('utf8_encode', $resultado); 
    }    
    
    //Passando vetor em forma de json
    echo json_encode($vetor);
}

function getTurma($link)
{
    $query = mysqli_query($link, "SELECT * FROM turma");    
    while($resultado = mysqli_fetch_assoc($query)){
        $vetor[] = array_map('utf8_encode', $resultado); 
    }    
    
    //Passando vetor em forma de json
    echo json_encode($vetor);
}
function getAluno($link)
{
    $disc=$_SESSION['disciplina'];
    $query = mysqli_query($link, "SELECT * FROM pauta where id_disciplina=$disc ORDER BY nome");    
    while($resultado = mysqli_fetch_assoc($query)){
        $vetor[] = array_map('utf8_encode', $resultado); 
    }    
    
    //Passando vetor em forma de json
    echo json_encode($vetor);
}

function getNt($link)
{
  if (isset($_REQUEST['id'])) {

 $id =$_REQUEST['id'];
   $query = mysqli_query($link, "SELECT * FROM aluno WHERE id='$id'");    
    while($resultado = mysqli_fetch_assoc($query)){

        $vetor[] = array_map('utf8_encode', $resultado); 
    }    
    
    //Passando vetor em forma de json
    echo json_encode($vetor);
    }
}

;

function edTaluno($link)
{
   if (isset($_REQUEST['edtnome'])) {
    $id =$_REQUEST['edtid'];
    $nome =utf8_decode($_REQUEST['edtnome']);
    $turma=$_REQUEST['edtturma'];
    $classe=$_REQUEST['edtclasse'];
    $insert="UPDATE aluno SET nome = '$nome' WHERE id = '$id'";
    $query=mysqli_query($link, $insert);
    $query=1;
    if ($query>0) {
      echo json_encode(array('success' => 1,'nome'=>'Dados do(a) aluno '.$_REQUEST['edtnome'].' actualizado com sucesso'));
    }
       
   }
}

// $sql='SELECT * FROM ano';

function cadnota($link)
{
   if (isset($_REQUEST['p1'])) {
      $p=$_REQUEST['p1'];
    $id=$_REQUEST['id'];
       echo json_encode(array('success' =>1,'idn'=>$id,'p'=>$p,'prova'=>1));
   }else if (isset($_REQUEST['p2'])) {
      $p=$_REQUEST['p2'];
    $id=$_REQUEST['id'];
       echo json_encode(array('success' =>1,'idn'=>$id,'p'=>$p,'prova'=>2));
   }else if (isset($_REQUEST['p3'])) {
      $p=$_REQUEST['p3'];
    $id=$_REQUEST['id'];
       echo json_encode(array('success' =>1,'idn'=>$id,'p'=>$p,'prova'=>3));
   }else if (isset($_REQUEST['p4'])) {
      $p=$_REQUEST['p4'];
    $id=$_REQUEST['id'];
       echo json_encode(array('success' =>1,'idn'=>$id,'p'=>$p,'prova'=>4));
   }else if (isset($_REQUEST['p5'])) {
      $p=$_REQUEST['p5'];
    $id=$_REQUEST['id'];
       echo json_encode(array('success' =>1,'idn'=>$id,'p'=>$p,'prova'=>5));
   }else if (isset($_REQUEST['p6'])) {
      $p=$_REQUEST['p6'];
    $id=$_REQUEST['id'];
       echo json_encode(array('success' =>1,'idn'=>$id,'p'=>$p,'prova'=>6));
   }
    
   
}