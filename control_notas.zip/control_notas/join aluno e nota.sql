
SELECT a.nome, a.id, n.p1, n.p2, n.p3, n.p4, n.p5, n.p6 FROM `aluno` as a INNER JOIN nota as n WHERE a.id=n.id_aluno
-- criar view 


-- criar view da tabela aluno JOIN nota
CREATE VIEW alunota AS
SELECT a.nome, a.id, n.p1, n.p2, n.p3, n.p4, n.p5, n.p6 FROM `aluno` as a INNER JOIN nota as n WHERE a.id=n.id_aluno

-- UPDATE nota do aluno 
UPDATE `alunota` SET `p2` = '8' WHERE `alunota`.`id` = 1;

INSERT INTO `nota` (`id_nota`, `id_aluno`, `id_disciplina`, `id_turma`, `id_ano`, `p1`, `p2`, `p3`, `p4`, `p5`, `p6`) 
VALUES (NULL, '5', '1', '1', '1', '', '', '', '', '', '');

-- buscar dados ou nota somente de um aluno e uma discplina
SELECT al.nome, al.id, n.p1, n.p2, n.p3, n.p4, n.p5, n.p6,an.ano
FROM `aluno` as al 
INNER JOIN nota as n 
INNER JOIN ano as an 
WHERE al.id=1 AND 
n.id_aluno=1 AND 
n.id_disciplina=1 AND 
n.id_ano=an.id_ano


-- buscar dados ou nota de varios aluno e uma discplina
SELECT al.nome, al.id, n.p1, n.p2, n.p3, n.p4, n.p5, n.p6,an.ano,tm.turma
FROM `aluno` as al 
INNER JOIN nota as n 
INNER JOIN ano as an
INNER JOIN turma as tm
WHERE al.id=n.id_aluno AND 
n.id_disciplina=1 AND 
n.id_ano=an.id_ano AND 
n.id_turma=tm.id_turma

INSERT INTO `nota` (`id_nota`, `id_aluno`, `id_disciplina`, `id_turma`, `id_ano`, `p1`, `p2`, `p3`, `p4`, `p5`, `p6`) 
VALUES (NULL, '4', '1', '1', '1', '', '', '', '', '', '');


INSERT INTO nota (id_nota, id_aluno, id_disciplina, id_turma, id_ano, p1, p2, p3, p4, p5, p6) 
VALUES (NULL, '$id_aluno', '$id_disciplina', '$id_turma', '$id_ano', '$p1', '$p2', '$p3', '$p4', '$p5', '$p6')

ALTER TABLE `disciplina_classe` ADD CONSTRAINT `id_discipli` FOREIGN KEY (`id_disciplina`) 
REFERENCES disciplinas (`id_disciplina`) ON DELETE NO ACTION ON UPDATE NO ACTION 





SELECT a.nome, a.id, n.p1, n.p2, n.p3, n.p4, n.p5, n.p6,dis.disciplina,n.id_disciplina 
FROM `aluno` as a 
INNER JOIN nota as n 
INNER JOIN disciplinas as dis 
WHERE a.id=n.id_aluno AND dis.id_disciplina=n.id_disciplina 