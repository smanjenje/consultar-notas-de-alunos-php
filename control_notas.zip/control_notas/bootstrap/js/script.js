$(document).ready(function(){
	$('.addaluno').click(function(){
		// Display Modal
		$('#addaluno').modal('show');
		// alert('ola'); 
	});
	$('.addturma').click(function(){
		// Display Modal
		$('#addturma').modal('show');
		// alert('ola'); 
	});
	$('.addclasse').click(function(){
		// Display Modal
		$('#addclasse').modal('show');
		// alert('ola'); 
	});


$('#addProf').submit(function(e) {
    e.preventDefault();

    $.ajax({
      type:'post',    //Definimos o método HTTP usado
      dataType: 'json', //Definimos o tipo de retorno
      url: '../script.php?op=cadprof',
      data: $(this).serialize(),//Definindo o arquivo onde serão buscados os dados
      success: function(dados){
         if (dados.success==1) {
          $('#addProf')[0].reset();
          alert(dados.info);
         }else if (dados.success==0) {
           alert(dados.info);
         }
      }
    });

 });

$('#cadturma').submit(function(e) {
    e.preventDefault();

    $.ajax({
      type:'post',    //Definimos o método HTTP usado
      dataType: 'json', //Definimos o tipo de retorno
      url: 'script.php?op=cadturma',
      data: $(this).serialize(),//Definindo o arquivo onde serão buscados os dados
      success: function(dados){
         if (dados.success==1) {
          $('#cadturma')[0].reset();
          alert(dados.nome);
          $('#addturma').modal('hide');
         }else if (dados.success==0) {
           alert(dados.info);
         }
      }
    });

 });

$('#cadclasse').submit(function(e) {
    e.preventDefault();

    $.ajax({
      type:'post',    //Definimos o método HTTP usado
      dataType: 'json', //Definimos o tipo de retorno
      url: 'script.php?op=cadclasse',
      data: $(this).serialize(),//Definindo o arquivo onde serão buscados os dados
      success: function(dados){
         if (dados.success==1) {
          $('#cadclasse')[0].reset();
          $('#addclasse').modal('slow/400/fast');
         }else if (dados.success==0) {
           alert(dados.info);
         }
      }
    });

 });


});