<?php
session_start();
$link = new mysqli("localhost", "root", "", "sgs");
$hoje = date('Y/m/d');
if(isset($_GET['op']) && !empty(isset($_GET['op']))) {
    $action = $_GET['op'];
    switch($action) {
        case 'cadturma' : cadturma($link);break;
        case 'cadclasse' : cadclasse($link);break;
    }
}

function cadturma($link)
{
   if (isset($_REQUEST['nome'])) {
    $nome = $_REQUEST['nome'];
       echo json_encode(array('success' => 1,'nome'=>$nome));
   }
}

function cadclasse($link)
{
   if (isset($_REQUEST['nome'])) {
    $nome = $_REQUEST['nome'];
       echo json_encode(array('success' => 1,'nome'=>$nome));
   }
}