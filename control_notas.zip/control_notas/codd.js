$.ajax({
            type:'post',    //Definimos o método HTTP usado
            dataType: 'json', //Definimos o tipo de retorno
            url: 'script.php?op=getNota',
            data: $(this).serialize(),//Definindo o arquivo onde serão buscados os dados
            success: function(dados){
              for(var i=0;dados.length>i;i++){
                $('#edtnome').val(dados[i].nome);
                $('#edtid').val(dados[i].id);
                $('#notaluno').modal('show');
                $('#notaluno').modal('handleUpdate')
                // edtturma
                // edtclasse
              }
              }
            });
  alert($( this ).val());



  // $('#pt').submit(function(e) {
//   e.preventDefault();
//       alert($( this ).val());    
// });

  // $('.nta').each(function() {

  //     $(this).submit(function(e) {
  //         e.preventDefault();
  //         alert($( this ).val()); 
  //       });
  //   });

  function() { // submit() corresponds to event submit
   alert("The Submit event has been triggered, form will be submitted");
  }