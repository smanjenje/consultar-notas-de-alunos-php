<div class="modal fade" id="addaluno" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add aluno</h4>
      </div>
      <form id="cadaluno">
        <div class="modal-body">
          <div class="form-group">
            <label for="recipient-name" class="control-label">Nome:</label>
            <input name="nome" type="text" class="form-control" id="recipient-name">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="control-label">turma:</label>
            <select id="turma" name="turma"></select>
            <label for="recipient-name" class="control-label">classe:</label>
            <select id="classe" name="classe"></select>
          </div>
          <!-- <div class="form-group">
            <label for="message-text" class="control-label">Detalhes:</label>
            <textarea name="detalhes" class="form-control" id="detalhes"></textarea>
          </div> -->
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-danger">Alterar</button>
        </div>
      </form>
    </div>
    <form id="pt"></form>
  </div>
</div>

<div class="modal fade" id="addturma" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add turma</h4>
      </div>
      <form id="cadturma">
        <div class="modal-body">
          <div class="form-group">
            <label for="recipient-name" class="control-label">Nome:</label>
            <input name="nome" type="text" class="form-control" id="recipient-name">
          </div>
          <!-- <div class="form-group">
            <label for="message-text" class="control-label">Detalhes:</label>
            <textarea name="detalhes" class="form-control" id="detalhes"></textarea>
          </div> -->
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-danger">Alterar</button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="addclasse" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add classe</h4>
      </div>
      <form id="cadclasse">
        <div class="modal-body">
          <div class="form-group">
            <label for="recipient-name" class="control-label">Nome:</label>
            <input name="nome" type="text" class="form-control" id="recipient-name">
          </div>
          <!-- <div class="form-group">
            <label for="message-text" class="control-label">Detalhes:</label>
            <textarea name="detalhes" class="form-control" id="detalhes"></textarea>
          </div> -->
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-danger">Alterar</button>
        </div>
      </form>
    </div>
  </div>
</div>



<div class="modal fade" id="edtaluno" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add aluno</h4>
      </div>
      <form id="edtaluno">
        <div class="modal-body">
          <div class="form-group">
            <label for="recipient-name" class="control-label">Nome:</label>
            <input name="edtnome" type="text" class="form-control" id="edtnome">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="control-label">turma:</label>
            <select id="edtturma" name="edtturma" class="turma"></select>
            <label for="recipient-name" class="control-label">classe:</label>
            <select id="edtclasse" name="edtclasse" class="classe"></select>
          </div>
          <!-- <div class="form-group">
            <label for="message-text" class="control-label">Detalhes:</label>
            <textarea name="detalhes" class="form-control" id="detalhes"></textarea>
          </div> -->
        </div>
        <div class="modal-footer">
          <input type="hidden" name="edtid" value="" id="edtid">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-danger">Alterar</button>
        </div>
      </form>
    </div>
    <form id="pt"></form>
  </div>
</div>

<div class="modal fade" id="getnota" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add nota</h4>
        <span id="trimestre"></span><strong>Trimestre</strong>
        <b>Disciplina:</b><span class="sesDisciplina"></span>
      </div>
      <form id="saveNota">
        <div class="modal-body">
          <div class="form-group">
            <label for="recipient-name" class="control-label">Nome:</label>
            <span id="alunome"></span>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="control-label">Nota actual:</label>
            <span id="alunota"></span>
          </div>
           <div class="form-group">
            <label for="recipient-name" class="control-label">Nova nota:</label>
            <input name="edtnota" size="4" type="text" class="form-control" id="edtnota">
          </div>
          <!-- <div class="form-group">
            <label for="message-text" class="control-label">Detalhes:</label>
            <textarea name="detalhes" class="form-control" id="detalhes"></textarea>
          </div> -->
        </div>
        <div class="modal-footer">
          <input type="hidden" name="alunoid" value="" id="alunoid">
          <input type="hidden" name="p" value="" id="prova">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-danger">Alterar</button>
        </div>
      </form>
    </div>
    <form id="pt"></form>
  </div>
</div>

<div class="modal fade" id="adddisplina" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Selecionar discplina</h4>
        
      </div>
      <form id="sessionDisciplina" >
        <div class="modal-body">
          <div class="form-group">
            <label for="recipient-name" class="control-label">Nome:</label>
            <span id="alunome"></span>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="control-label">Displina:</label>
            <select id="discipli" name="discipli" class="discipli"></select>
          </div>
          <!-- <div class="form-group">
            <label for="message-text" class="control-label">Detalhes:</label>
            <textarea name="detalhes" class="form-control" id="detalhes"></textarea>
          </div> -->
        </div>
        <div class="modal-footer">
          <input type="hidden" name="" value="" id="">
          
          <button type="submit" class="btn btn-danger">Alterar</button>
        </div>
      </form>
    </div>
    <form id="pt"></form>
  </div>
</div>